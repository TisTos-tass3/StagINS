import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';

import Layout from './components/Layout';
import Login from './pages/Login';
import Dashboard from './pages/dashboard';
import Stagiaires from './pages/Stagiaires';
import Stages from './pages/Stages';
import StagiaireDetail from './pages/StagiaireDetails';
import Rapports from './pages/Rapports';
import Encadrants from './pages/Encadrants';

function AppContent() {
  const { user } = useAuth();

  return (
    
    <div className="min-h-screen">
     
      <Routes>
     
        <Route
          path="/login"
          element={!user ? <Login /> : <Navigate to="/" replace />}
        />

      
        <Route
          path="/"
          element={
            <ProtectedRoute>
              <Layout>
                <Dashboard />
              </Layout>
            </ProtectedRoute>
          }
        />

        <Route
          path="/stagiaires"
          element={
            <ProtectedRoute>
              <Layout>
                <Stagiaires />
              </Layout>
            </ProtectedRoute>
          }
        />

        <Route
          path="/stages"
          element={
            <ProtectedRoute>
              <Layout>
                <Stages />
              </Layout>
            </ProtectedRoute>
          }
        />

        
       
        <Route
          path="/rapports"
          element={
            <ProtectedRoute>
              <Layout>
                <Rapports />
              </Layout>
            </ProtectedRoute>
          }
        />
         <Route path="/stagiaires/api/:stagiaireId/detail/" 
            element={
              <ProtectedRoute>
                <StagiaireDetail /> 
              </ProtectedRoute>
            }
          />


        <Route
          path="/encadrants"
          element={
            <ProtectedRoute requiredPermission="can_edit">
              <Layout>
                <Encadrants />
              </Layout>
            </ProtectedRoute>
          }
        />

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <Router>
        <AppContent />
      </Router>
    </AuthProvider>
  );
}

export default App;