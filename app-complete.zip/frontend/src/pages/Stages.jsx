
import React, { useState, useEffect, useCallback } from "react";
import { PlusCircle, Download, Search, Calendar, Filter, X } from "lucide-react";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import StagesTable from "../components/tables/StagesTable";
import StageForm from "../components/forms/StageForm";
import AlertesStages from "../components/AlertesStages";
import ErrorMessageModal from "../components/modals/ErrorMessageModal";

export default function StagesPage() {
  const API = "http://localhost:8000";
  

  const [stages, setStages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tableError, setTableError] = useState(null);
  const [dashboardData, setDashboardData] = useState(null);

  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingStage, setEditingStage] = useState(null);

  
  const [searchTerm, setSearchTerm] = useState("");
  const [dateFilter, setDateFilter] = useState({
    type: "none",
    year: new Date().getFullYear().toString(),
    month: new Date().getMonth() + 1,
    startDate: "",
    endDate: ""
  });
  const [showDateFilter, setShowDateFilter] = useState(false);

 
  const fetchStages = useCallback(async () => {
    setLoading(true);
    try {
      const response = await fetch(`${API}/stages/api/`);
      if (!response.ok) throw new Error("Erreur réseau");
      const data = await response.json();
      setStages(data);
    } catch (err) {
      setTableError(err.message || "Erreur lors du chargement des stages");
      console.error("Erreur de récupération des stages:", err);
    } finally {
      setLoading(false);
    }
  }, [API]);

  
  const fetchDashboardData = useCallback(async () => {
    try {
      const response = await fetch(`${API}/dashboard/api/`);
      if (response.ok) {
        const data = await response.json();
        setDashboardData(data);
      }
    } catch (error) {
      console.error("Erreur chargement dashboard:", error);
    }
  }, [API]);

  useEffect(() => {
    fetchStages();
    fetchDashboardData();
  }, [fetchStages, fetchDashboardData]);


  
  const handleStageSaved = () => {
    setIsModalOpen(false);
    setEditingStage(null);
    fetchStages();
    fetchDashboardData();
  };

  const handleEdit = (stage) => {
    setEditingStage(stage);
    setIsModalOpen(true);
  };

  const handleAddClick = () => {
    setEditingStage(null);
    setIsModalOpen(true);
  };

  
  const filterByDate = (stage) => {
    if (dateFilter.type === "none") return true;

    const stageDate = new Date(stage.date_debut);
    
    switch (dateFilter.type) {
      case "year":
        if (!dateFilter.year) return true;
        return stageDate.getFullYear() === parseInt(dateFilter.year);
      
      case "month":
        if (!dateFilter.year || !dateFilter.month) return true;
        return stageDate.getFullYear() === parseInt(dateFilter.year) && 
               stageDate.getMonth() + 1 === parseInt(dateFilter.month);
      
      case "range":
        if (!dateFilter.startDate || !dateFilter.endDate) return true;
        const start = new Date(dateFilter.startDate);
        const end = new Date(dateFilter.endDate);
        return stageDate >= start && stageDate <= end;
      
      default:
        return true;
    }
  };

  
  const filteredStages = stages.filter((stage) => {
    const matchesSearch = 
      stage.theme?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      stage.stagiaire?.nom?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      stage.stagiaire?.prenom?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesDate = filterByDate(stage);
    
    return matchesSearch && matchesDate;
  });

 
  const resetDateFilter = () => {
    setDateFilter({
      type: "none",
      year: new Date().getFullYear().toString(),
      month: new Date().getMonth() + 1,
      startDate: "",
      endDate: ""
    });
  };

  
  const isValidYear = (year) => {
    const yearNum = parseInt(year);
    return !isNaN(yearNum) && yearNum >= 1900 && yearNum <= new Date().getFullYear() + 10;
  };

 
  const downloadPDF = () => {
    if (!filteredStages.length) {
      setTableError("Aucun stage à exporter.");
      return;
    }
    
    const doc = new jsPDF();
    
    
    let title = "Liste des Stages";
    if (dateFilter.type !== "none") {
      title += " - Filtre: ";
      switch (dateFilter.type) {
        case "year":
          title += `Année ${dateFilter.year}`;
          break;
        case "month":
          const monthNames = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];
          title += `${monthNames[dateFilter.month - 1]} ${dateFilter.year}`;
          break;
        case "range":
          title += `Du ${dateFilter.startDate} au ${dateFilter.endDate}`;
          break;
      }
    }
    
    doc.text(title, 14, 15);
    autoTable(doc, {
      head: [["Thème", "Stagiaire", "Encadrant", "Début", "Fin", "Statut"]],
      body: filteredStages.map((s) => [
        s.theme,
        `${s.stagiaire?.prenom || ''} ${s.stagiaire?.nom || ''}`,
        `${s.encadrant?.prenom || ''} ${s.encadrant?.nom || ''}`,
        s.date_debut,
        s.date_fin,
        s.statut,
      ]),
      startY: 20,
    });
    doc.save("stages_list.pdf");
  };

  return (
    <div>
      {/* Section Alertes */}
      {dashboardData && <AlertesStages alertes={dashboardData} />}

      {/* En-tête avec recherche et boutons */}
      <div className="flex justify-between items-center mb-6 flex-wrap gap-4">
        <div className="flex items-center gap-4 flex-1 min-w-0">
      
          <div className="relative w-full max-w-sm">
            <Search size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Rechercher un stage..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full p-2 pl-10 border-0 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white shadow-md"
            />
          </div>

          {/* Bouton filtre date */}
          <div className="relative">
            <button
              onClick={() => setShowDateFilter(!showDateFilter)}
              className={`flex items-center gap-2 px-4 py-2 rounded-md transition-colors shadow-sm ${
                dateFilter.type !== "none" 
                  ? "bg-blue-100 text-blue-700 border border-blue-300" 
                  : "bg-white text-gray-700 border border-gray-300 hover:bg-gray-50"
              }`}
            >
              <Filter size={18} />
              Filtre Date
              {dateFilter.type !== "none" && (
                <span className="bg-blue-500 text-white rounded-full w-5 h-5 text-xs flex items-center justify-center">
                  !
                </span>
              )}
            </button>

            {/* Menu déroulant filtre date */}
            {showDateFilter && (
              <div className="absolute top-full left-0 mt-2 w-80 bg-white border border-gray-200 rounded-lg shadow-lg z-10 p-4">
                <div className="flex justify-between items-center mb-3">
                  <h3 className="font-semibold text-gray-800">Filtrer par date</h3>
                  <button
                    onClick={() => setShowDateFilter(false)}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <X size={18} />
                  </button>
                </div>

                <div className="space-y-3">
                  {/* Filtre par année */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Par année
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="number"
                        value={dateFilter.year}
                        onChange={(e) => setDateFilter(prev => ({ 
                          ...prev, 
                          type: "year", 
                          year: e.target.value 
                        }))}
                        placeholder="Ex: 2024"
                        min="1900"
                        max={new Date().getFullYear() + 10}
                        className="flex-1 p-2 border border-gray-300 rounded-md text-sm"
                      />
                    </div>
                    {dateFilter.year && !isValidYear(dateFilter.year) && (
                      <p className="text-red-500 text-xs mt-1">
                        Année invalide (1900 - {new Date().getFullYear() + 10})
                      </p>
                    )}
                  </div>

                  {/* Filtre par mois */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Par mois
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="number"
                        value={dateFilter.year}
                        onChange={(e) => setDateFilter(prev => ({ 
                          ...prev, 
                          type: "month", 
                          year: e.target.value 
                        }))}
                        placeholder="Année"
                        min="1900"
                        max={new Date().getFullYear() + 10}
                        className="flex-1 p-2 border border-gray-300 rounded-md text-sm"
                      />
                      <select
                        value={dateFilter.month}
                        onChange={(e) => setDateFilter(prev => ({ 
                          ...prev, 
                          type: "month", 
                          month: e.target.value 
                        }))}
                        className="flex-1 p-2 border border-gray-300 rounded-md text-sm"
                      >
                        <option value="1">Janvier</option>
                        <option value="2">Février</option>
                        <option value="3">Mars</option>
                        <option value="4">Avril</option>
                        <option value="5">Mai</option>
                        <option value="6">Juin</option>
                        <option value="7">Juillet</option>
                        <option value="8">Août</option>
                        <option value="9">Septembre</option>
                        <option value="10">Octobre</option>
                        <option value="11">Novembre</option>
                        <option value="12">Décembre</option>
                      </select>
                    </div>
                    {dateFilter.year && !isValidYear(dateFilter.year) && (
                      <p className="text-red-500 text-xs mt-1">
                        Année invalide (1900 - {new Date().getFullYear() + 10})
                      </p>
                    )}
                  </div>

                  {/* Filtre par dates */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Par plage de dates
                    </label>
                    <div className="space-y-2">
                      <input
                        type="date"
                        value={dateFilter.startDate}
                        onChange={(e) => setDateFilter(prev => ({ 
                          ...prev, 
                          type: "range", 
                          startDate: e.target.value 
                        }))}
                        className="w-full p-2 border border-gray-300 rounded-md text-sm"
                      />
                      <input
                        type="date"
                        value={dateFilter.endDate}
                        onChange={(e) => setDateFilter(prev => ({ 
                          ...prev, 
                          type: "range", 
                          endDate: e.target.value 
                        }))}
                        className="w-full p-2 border border-gray-300 rounded-md text-sm"
                      />
                    </div>
                  </div>

                  {/* Boutons d'action */}
                  <div className="flex gap-2 pt-2">
                    <button
                      onClick={resetDateFilter}
                      className="flex-1 px-3 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition-colors text-sm"
                    >
                      Réinitialiser
                    </button>
                    <button
                      onClick={() => setShowDateFilter(false)}
                      className="flex-1 px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors text-sm"
                    >
                      Appliquer
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

         
          {dateFilter.type !== "none" && (
            <div className="flex items-center gap-2 text-sm text-blue-600 bg-blue-50 px-3 py-1 rounded-full">
              <Calendar size={14} />
              <span>
                {dateFilter.type === "year" && `Année: ${dateFilter.year}`}
                {dateFilter.type === "month" && 
                  `Mois: ${new Date(dateFilter.year, dateFilter.month - 1).toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' })}`
                }
                {dateFilter.type === "range" && 
                  `Du ${dateFilter.startDate} au ${dateFilter.endDate}`
                }
              </span>
              <button
                onClick={resetDateFilter}
                className="text-blue-400 hover:text-blue-600"
              >
                <X size={14} />
              </button>
            </div>
          )}
        </div>

        <div className="flex gap-4">
          <button
            onClick={handleAddClick}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors shadow-sm"
          >
            <PlusCircle size={20} />
            Ajouter un Stage
          </button>
          <button
            onClick={downloadPDF}
            className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors shadow-sm"
          >
            <Download size={20} />
            Exporter PDF
          </button>
        </div>
      </div>

      {/* Tableau des stages */}
      <StagesTable 
        stages={filteredStages} 
        loading={loading} 
        onStageDeleted={fetchStages} 
        onStageEdit={handleEdit}
        setParentError={setTableError}
      />

      {/* Modal d'erreur */}
      <ErrorMessageModal
        message={tableError}
        onClose={() => setTableError(null)}
      />

      {/* Modal d'ajout/modification de stage */}
      {isModalOpen && (
        <StageForm
          initial={editingStage}
          onClose={() => {
            setIsModalOpen(false);
            setEditingStage(null);
          }}
          onSaved={handleStageSaved}
        />
      )}
    </div>
  );
}