
import React, { useState, useEffect } from "react";
import GenericModal from "./GenericForm";
import SearchableSelect from "../SearchableSelect";
import { 
  FileText, Calendar, Loader2, 
  User, CheckCircle, AlertCircle, 
  BookOpen, MapPin
} from "lucide-react";


const API = "http://localhost:8000";
const NIVEAU_ETUDE_OPTIONS = ['Bac +2', 'Bac +3', 'Bac +5', 'Bac +8'];
const TYPE_STAGE_OPTIONS = ['Academique', 'Professionnel'];

export default function StageForm({ initial, onClose, onSaved }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  
  const [step, setStep] = useState(1);
  const [stagiaireChoice, setStagiaireChoice] = useState('new');
  
  const [stagiaires, setStagiaires] = useState([]);
  const [stagiaireOptions, setStagiaireOptions] = useState([]);
  const [encadrantOptions, setEncadrantOptions] = useState([]);
  const [searchLoading, setSearchLoading] = useState(false);

  const [formData, setFormData] = useState({
    nom: "", 
    prenom: "", 
    ecole: "", 
    specialite: "", 
    niveau_etude: "Bac +2", 
    email: "", 
    telephone: "",
    theme: "", 
    type_stage: "Academique", 
    date_debut: "", 
    date_fin: "", 
    lieu_affectation: "",
    stagiaire: "", 
    encadrant: "",
    existingStagiaire: "",
  });

  const [errors, setErrors] = useState({});

  const isEditMode = !!initial;

 
  const loadOptions = async () => {
    setSearchLoading(true);
    try {
      const [stagiairesRes, encadrantsRes] = await Promise.all([
        fetch(`${API}/stagiaires/api/`),
        fetch(`${API}/encadrants/api/`)
      ]);

      if (!stagiairesRes.ok || !encadrantsRes.ok) {
        throw new Error("Erreur lors du chargement des données");
      }

      const stagiairesData = await stagiairesRes.json();
      const encadrantsData = await encadrantsRes.json();
      
      setStagiaires(stagiairesData);
      
      setStagiaireOptions(stagiairesData.map(s => ({
        value: s.id,
        label: `${s.matricule || ''} - ${s.prenom} ${s.nom} ${s.ecole ? `(${s.ecole})` : ''}`
      })));

      setEncadrantOptions(encadrantsData.map(e => ({
        value: e.id,
        label: `${e.prenom} ${e.nom} - ${e.institution}`
      })));

    } catch (err) {
      console.error("Erreur chargement options:", err);
      setError("Erreur lors du chargement des listes de stagiaires/encadrants.");
    } finally {
      setSearchLoading(false);
    }
  };

  useEffect(() => {
    loadOptions();
  }, []);


  useEffect(() => {
    if (isEditMode && initial) {
      setStep(2);
      setFormData(prev => ({
        ...prev,
        theme: initial.theme || "",
        type_stage: initial.type_stage || "Academique",
        date_debut: initial.date_debut || "",
        date_fin: initial.date_fin || "",
        lieu_affectation: initial.lieu_affectation || "",
        stagiaire: initial.stagiaire?.id || initial.stagiaire_id || "",
        encadrant: initial.encadrant?.id || initial.encadrant_id || "",
      }));
    }
  }, [initial, isEditMode]);

  
  useEffect(() => {
    if (stagiaireChoice === 'existing' && formData.existingStagiaire && stagiaires.length > 0) {
      const selectedId = parseInt(formData.existingStagiaire);
      const selectedStagiaire = stagiaires.find(s => s.id === selectedId);
      if (selectedStagiaire) {
        setFormData(prev => ({
          ...prev,
          ecole: selectedStagiaire.ecole || "",
          specialite: selectedStagiaire.specialite || "",
          niveau_etude: selectedStagiaire.niveau_etude || "Bac +2"
        }));
      }
    }
  }, [formData.existingStagiaire, stagiaireChoice, stagiaires]);

 
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: null }));
    }
    setError(null);
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: null }));
    }
    setError(null);
  };

  const handleStagiaireChoiceChange = (choice) => {
    setStagiaireChoice(choice);
    if (choice === 'new') {
      setFormData(prev => ({
        ...prev,
        existingStagiaire: "",
        nom: "", 
        prenom: "", 
        email: "", 
        telephone: "",
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        nom: "", 
        prenom: "", 
        email: "", 
        telephone: "",
      }));
    }
    setError(null);
    setErrors({});
  };

  const validateStep1 = () => {
    const newErrors = {};

    if (stagiaireChoice === 'new') {
      if (!formData.nom.trim()) newErrors.nom = 'Le nom est obligatoire';
      if (!formData.prenom.trim()) newErrors.prenom = 'Le prénom est obligatoire';
      if (!formData.email.trim()) {
        newErrors.email = 'L\'email est obligatoire';
      } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
        newErrors.email = 'Format d\'email invalide';
      }
    } else {
      if (!formData.existingStagiaire) newErrors.existingStagiaire = 'Veuillez sélectionner un stagiaire existant';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  
  const validateStep2 = () => {
    const newErrors = {};

    if (!formData.theme.trim()) newErrors.theme = 'Le thème du stage est obligatoire';
    if (!formData.date_debut) newErrors.date_debut = 'La date de début est obligatoire';
    if (!formData.date_fin) newErrors.date_fin = 'La date de fin est obligatoire';
    
    if (!formData.lieu_affectation.trim()) newErrors.lieu_affectation = 'Le lieu d\'affectation est obligatoire';
    if (isEditMode && !formData.stagiaire) newErrors.stagiaire = 'Le stagiaire est obligatoire';

    if (formData.date_debut && formData.date_fin) {
      const debut = new Date(formData.date_debut);
      const fin = new Date(formData.date_fin);
      if (debut >= fin) newErrors.date_fin = 'La date de fin doit être postérieure à la date de début';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNextStep = () => {
    if (validateStep1()) {
      setStep(2);
      setError(null);
    }
  };

  const handlePreviousStep = () => {
    setStep(1);
    setError(null);
    setErrors({});
  };

 
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateStep2()) return;
    
    setLoading(true);
    setError(null);
    setErrors({});

    try {
      let stagiaireId;

      if (isEditMode) {
        const stageData = {
          theme: formData.theme,
          type_stage: formData.type_stage,
          date_debut: formData.date_debut,
          date_fin: formData.date_fin,
          lieu_affectation: formData.lieu_affectation,
          stagiaire: formData.stagiaire,
          encadrant: formData.encadrant,
        };

        const response = await fetch(`${API}/stages/api/${initial.id}/`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(stageData),
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.message || "Erreur lors de la mise à jour du stage");
        }

        onSaved();
      } else {
        if (stagiaireChoice === 'new') {
          const stagiaireData = {
            nom: formData.nom,
            prenom: formData.prenom,
            ecole: formData.ecole,
            specialite: formData.specialite,
            niveau_etude: formData.niveau_etude,
            email: formData.email,
            telephone: formData.telephone,
          };

          const stagiaireResponse = await fetch(`${API}/stagiaires/api/create/`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(stagiaireData),
          });

          if (!stagiaireResponse.ok) {
            const errorData = await stagiaireResponse.json();
            throw new Error(errorData.message || "Erreur lors de la création du stagiaire");
          }

          const newStagiaire = await stagiaireResponse.json();
          stagiaireId = newStagiaire.id;
        } else {
          stagiaireId = formData.existingStagiaire;

          const updatedStagiaireData = {
            ecole: formData.ecole,
            specialite: formData.specialite,
            niveau_etude: formData.niveau_etude,
          };

          const currentResponse = await fetch(`${API}/stagiaires/api/${stagiaireId}/`);
          if (currentResponse.ok) {
            const currentStagiaire = await currentResponse.json();
            const finalData = { ...currentStagiaire, ...updatedStagiaireData };

            await fetch(`${API}/stagiaires/api/${stagiaireId}/`, {
              method: "PUT",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(finalData),
            });
          }
        }

        const stageData = {
          theme: formData.theme,
          type_stage: formData.type_stage,
          date_debut: formData.date_debut,
          date_fin: formData.date_fin,
          stagiaire: stagiaireId,
          encadrant: formData.encadrant,
          lieu_affectation: formData.lieu_affectation,
        };

        const stageResponse = await fetch(`${API}/stages/api/create/`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(stageData),
        });

        if (!stageResponse.ok) {
          const errorData = await stageResponse.json();
          throw new Error(errorData.message || "Erreur lors de la création du stage");
        }

        onSaved();
      }
    } catch (err) {
      setError(err.message || "Une erreur est survenue lors de la soumission");
      console.error("Erreur de soumission:", err);
    } finally {
      setLoading(false);
    }
  };

  const modalTitle = isEditMode ? "Modifier un Stage" : "Ajouter un nouveau Stage";
  const submitButtonText = isEditMode ? "Mettre à jour" : "Créer le stage";

  const getInputClassName = (fieldName) => {
    const baseClass = "w-full p-2 border rounded-lg focus:ring-blue-500 focus:border-blue-500 transition-colors text-sm";
    return errors[fieldName] ? `${baseClass} border-red-500 bg-red-50 focus:ring-red-200` : `${baseClass} border-gray-300`;
  };

  return (
    <GenericModal
      isOpen={true}
      onClose={onClose}
      title={modalTitle}
      icon={FileText}
      size="lg"
      loading={loading}
    >
      {error && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-center space-x-2">
          <AlertCircle size={18} className="text-red-600" />
          <p className="text-red-700 text-sm font-medium">{error}</p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Étape 1 - Informations du stagiaire */}
        {!isEditMode && step === 1 && (
          <div className="space-y-6">
            <div className="border-b border-gray-300 pb-4">
              <h4 className="text-lg font-semibold text-gray-800">Étape 1/2: Informations du Stagiaire</h4>
            </div>
            
            {/* Choix du type de stagiaire */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">Type de stagiaire</label>
              <div className="flex space-x-6">
                <label className="flex items-center">
                  <input
                    type="radio"
                    name="stagiaireChoice"
                    value="new"
                    checked={stagiaireChoice === 'new'}
                    onChange={(e) => handleStagiaireChoiceChange(e.target.value)}
                    className="mr-2 h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500"
                  />
                  Nouveau stagiaire
                </label>
                <label className="flex items-center">
                  <input
                    type="radio"
                    name="stagiaireChoice"
                    value="existing"
                    checked={stagiaireChoice === 'existing'}
                    onChange={(e) => handleStagiaireChoiceChange(e.target.value)}
                    className="mr-2 h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500"
                  />
                  Stagiaire existant
                </label>
              </div>
            </div>

            {/* Nouveau stagiaire */}
            {stagiaireChoice === 'new' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Nom <span className="text-red-500">*</span>
                  </label>
                  <input
                    name="nom"
                    value={formData.nom}
                    onChange={handleChange}
                    type="text"
                    className={getInputClassName('nom')}
                  />
                  {errors.nom && (
                    <p className="mt-1 text-xs text-red-600 flex items-center space-x-1">
                      <AlertCircle size={12} />
                      <span>{errors.nom}</span>
                    </p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Prénom <span className="text-red-500">*</span>
                  </label>
                  <input
                    name="prenom"
                    value={formData.prenom}
                    onChange={handleChange}
                    type="text"
                    className={getInputClassName('prenom')}
                  />
                  {errors.prenom && (
                    <p className="mt-1 text-xs text-red-600 flex items-center space-x-1">
                      <AlertCircle size={12} />
                      <span>{errors.prenom}</span>
                    </p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email <span className="text-red-500">*</span>
                  </label>
                  <input
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    type="email"
                    className={getInputClassName('email')}
                  />
                  {errors.email && (
                    <p className="mt-1 text-xs text-red-600 flex items-center space-x-1">
                      <AlertCircle size={12} />
                      <span>{errors.email}</span>
                    </p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Téléphone
                  </label>
                  <input
                    name="telephone"
                    value={formData.telephone}
                    onChange={handleChange}
                    type="text"
                    className={getInputClassName('telephone')}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    École
                  </label>
                  <input
                    name="ecole"
                    value={formData.ecole}
                    onChange={handleChange}
                    type="text"
                    className={getInputClassName('ecole')}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Spécialité
                  </label>
                  <input
                    name="specialite"
                    value={formData.specialite}
                    onChange={handleChange}
                    type="text"
                    className={getInputClassName('specialite')}
                  />
                </div>

                <div className="md:col-span-2">
                  <label htmlFor="niveau_etude" className="block text-sm font-medium text-gray-700 mb-1">
                    Niveau d'étude
                  </label>
                  <select
                    name="niveau_etude"
                    value={formData.niveau_etude}
                    onChange={handleChange}
                    className={getInputClassName('niveau_etude')}
                  >
                    {NIVEAU_ETUDE_OPTIONS.map(option => (
                      <option key={option} value={option}>{option}</option>
                    ))}
                  </select>
                </div>
              </div>
            )}

            {/* Stagiaire existant */}
            {stagiaireChoice === 'existing' && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Sélectionner un stagiaire existant <span className="text-red-500">*</span>
                  </label>
                  <SearchableSelect
                    options={stagiaireOptions}
                    value={formData.existingStagiaire}
                    onChange={(value) => handleSelectChange('existingStagiaire', value)}
                    placeholder="Rechercher un stagiaire..."
                    loading={searchLoading}
                    className={errors.existingStagiaire ? 'border-red-500 bg-red-50' : ''}
                  />
                  {errors.existingStagiaire && (
                    <p className="mt-1 text-xs text-red-600 flex items-center space-x-1">
                      <AlertCircle size={12} />
                      <span>{errors.existingStagiaire}</span>
                    </p>
                  )}
                </div>

                <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                  <h5 className="font-medium text-blue-800 mb-3 text-sm">Mettre à jour les informations académiques</h5>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        École
                      </label>
                      <input
                        name="ecole"
                        value={formData.ecole}
                        onChange={handleChange}
                        type="text"
                        className={getInputClassName('ecole')}
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Spécialité
                      </label>
                      <input
                        name="specialite"
                        value={formData.specialite}
                        onChange={handleChange}
                        type="text"
                        className={getInputClassName('specialite')}
                      />
                    </div>

                    <div className="md:col-span-2">
                      <label htmlFor="niveau_etude" className="block text-sm font-medium text-gray-700 mb-1">
                        Niveau d'étude
                      </label>
                      <select
                        name="niveau_etude"
                        value={formData.niveau_etude}
                        onChange={handleChange}
                        className={getInputClassName('niveau_etude')}
                      >
                        {NIVEAU_ETUDE_OPTIONS.map(option => (
                          <option key={option} value={option}>{option}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>
              </div>
            )}

            <div className="flex justify-end pt-4 border-t border-gray-200">
              <button
                type="button"
                onClick={handleNextStep}
                disabled={loading}
                className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium text-sm disabled:opacity-50"
              >
                Suivant
              </button>
            </div>
          </div>
        )}

        {/* Étape 2 - Informations du stage */}
        {(isEditMode || step === 2) && (
          <div className="space-y-6">
            <div className="border-b border-gray-200 pb-4">
              <h4 className="text-lg font-semibold text-gray-800">
                {isEditMode ? "Informations du Stage" : "Étape 2/2: Informations du Stage"}
              </h4>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Thème <span className="text-red-500">*</span>
                </label>
                <input
                  name="theme"
                  value={formData.theme}
                  onChange={handleChange}
                  type="text"
                  className={getInputClassName('theme')}
                />
                {errors.theme && (
                  <p className="mt-1 text-xs text-red-600 flex items-center space-x-1">
                    <AlertCircle size={12} />
                    <span>{errors.theme}</span>
                  </p>
                )}
              </div>

              <div>
                <label htmlFor="type_stage" className="block text-sm font-medium text-gray-700 mb-1">
                  Type de Stage <span className="text-red-500">*</span>
                </label>
                <select
                  name="type_stage"
                  value={formData.type_stage}
                  onChange={handleChange}
                  className={getInputClassName('type_stage')}
                >
                  {TYPE_STAGE_OPTIONS.map(option => (
                    <option key={option} value={option}>{option}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Lieu d'Affectation <span className="text-red-500">*</span>
                </label>
                <input
                  name="lieu_affectation"
                  value={formData.lieu_affectation}
                  onChange={handleChange}
                  type="text"
                  className={getInputClassName('lieu_affectation')}
                />
                {errors.lieu_affectation && (
                  <p className="mt-1 text-xs text-red-600 flex items-center space-x-1">
                    <AlertCircle size={12} />
                    <span>{errors.lieu_affectation}</span>
                  </p>
                )}
              </div>

              {/* Encadrant */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Encadrant 
                </label>
                <SearchableSelect
                  options={encadrantOptions}
                  value={formData.encadrant}
                  onChange={(value) => handleSelectChange('encadrant', value)}
                  placeholder="Rechercher un encadrant..."
                  loading={searchLoading}
                  className={errors.encadrant ? 'border-red-500 bg-red-50' : ''}
                />
                
                
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Date de Début <span className="text-red-500">*</span>
                </label>
                <input
                  name="date_debut"
                  value={formData.date_debut}
                  onChange={handleChange}
                  type="date"
                  className={getInputClassName('date_debut')}
                />
                {errors.date_debut && (
                  <p className="mt-1 text-xs text-red-600 flex items-center space-x-1">
                    <AlertCircle size={12} />
                    <span>{errors.date_debut}</span>
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Date de Fin <span className="text-red-500">*</span>
                </label>
                <input
                  name="date_fin"
                  value={formData.date_fin}
                  onChange={handleChange}
                  type="date"
                  className={getInputClassName('date_fin')}
                />
                {errors.date_fin && (
                  <p className="mt-1 text-xs text-red-600 flex items-center space-x-1">
                    <AlertCircle size={12} />
                    <span>{errors.date_fin}</span>
                  </p>
                )}
              </div>

              

              {/* Stagiaire édition */}
              {isEditMode && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Stagiaire <span className="text-red-500">*</span>
                  </label>
                  <SearchableSelect
                    options={stagiaireOptions}
                    value={formData.stagiaire}
                    onChange={(value) => handleSelectChange('stagiaire', value)}
                    placeholder="Rechercher un stagiaire..."
                    loading={searchLoading}
                    className={errors.stagiaire ? 'border-red-500 bg-red-50' : ''}
                  />
                  {errors.stagiaire && (
                    <p className="mt-1 text-xs text-red-600 flex items-center space-x-1">
                      <AlertCircle size={12} />
                      <span>{errors.stagiaire}</span>
                    </p>
                  )}
                </div>
              )}
            </div>

            <div className="flex justify-between pt-4 border-t border-gray-200">
              {!isEditMode && (
                <button
                  type="button"
                  onClick={handlePreviousStep}
                  disabled={loading}
                  className="px-6 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors font-medium text-sm disabled:opacity-50"
                >
                  Précédent
                </button>
              )}
              <button
                type="submit"
                disabled={loading}
                className={`px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium text-sm disabled:opacity-50 flex items-center space-x-2 ${
                  !isEditMode ? 'ml-auto' : ''
                }`}
              >
                {loading ? (
                  <>
                    <Loader2 size={16} className="animate-spin" />
                    <span>Traitement...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle size={16} />
                    <span>{submitButtonText}</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}
      </form>
    </GenericModal>
  );
}