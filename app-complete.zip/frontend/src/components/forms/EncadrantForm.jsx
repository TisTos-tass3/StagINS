
import React, { useState, useEffect } from 'react';
import { 
  User, Mail, Phone, Building, 
  CheckCircle, AlertCircle, Loader2 
} from 'lucide-react';
import GenericModal from './GenericForm';

export default function EncadrantModal({ 
  initial, 
  onClose, 
  onSaved, 
  loading: externalLoading 
}) {
  const [formData, setFormData] = useState({
    nom: '',
    prenom: '',
    institution: 'Interne',
    email: '',
    telephone: ''
  });
  
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [submitAttempted, setSubmitAttempted] = useState(false);


  const validateForm = () => {
    const newErrors = {};

    if (!formData.nom.trim()) newErrors.nom = 'Le nom est obligatoire';
    if (!formData.prenom.trim()) newErrors.prenom = 'Le prénom est obligatoire';
    if (!formData.email.trim()) {
      newErrors.email = 'L\'email est obligatoire';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Format d\'email invalide';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

 
  useEffect(() => {
    if (initial) {
      setFormData({
        nom: initial.nom || '',
        prenom: initial.prenom || '',
        institution: initial.institution || 'Interne',
        email: initial.email || '',
        telephone: initial.telephone || ''
      });
    }
  }, [initial]);


  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));

    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

 
  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitAttempted(true);
    setLoading(true);

    if (!validateForm()) {
      setLoading(false);
      return;
    }

    const url = initial 
      ? `http://localhost:8000/encadrants/api/${initial.id}/` 
      : 'http://localhost:8000/encadrants/api/create/';
    
    const method = initial ? 'PUT' : 'POST';

    try {
      const response = await fetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const responseData = await response.json();

      if (!response.ok) {
        let errorMessage = "Une erreur inconnue est survenue.";

        if (response.status === 400) {
          if (responseData.email) {
            setErrors(prev => ({ ...prev, email: responseData.email[0] }));
            errorMessage = null;
          } else if (responseData.telephone) {
            setErrors(prev => ({ ...prev, telephone: responseData.telephone[0] }));
            errorMessage = null;
          } else if (responseData.form_errors) {
            const formErrors = responseData.form_errors;
            Object.keys(formErrors).forEach(field => {
              setErrors(prev => ({ ...prev, [field]: formErrors[field][0] }));
            });
            errorMessage = null;
          } else if (responseData.error) {
            errorMessage = responseData.error;
          }
        } else if (response.status === 500) {
          errorMessage = "Erreur serveur. Veuillez réessayer plus tard.";
        }

        if (errorMessage) {
          setErrors({ submit: errorMessage });
        }
        
        setLoading(false);
        return;
      }

      onSaved(responseData);
    } catch (err) {
      setErrors({ submit: 'Erreur de connexion réseau ou du serveur.' });
      console.error("Erreur d'API:", err);
    } finally {
      setLoading(false);
    }
  };

 
  const getInputClassName = (fieldName) => {
    const baseClass = "w-full p-2 border rounded-lg focus:ring-blue-500 focus:border-blue-500 transition-colors text-sm";
    
   
    if (errors[fieldName]) {
      return `${baseClass} border-red-500 bg-red-50 focus:ring-red-200`;
    }
    return `${baseClass} border-gray-300`;
  };

  const isEditMode = !!initial;
  const isLoading = loading || externalLoading;

  const fields = [
    { field: "nom", label: "Nom", type: "text", required: true, placeholder: "Entrez le nom", icon: <User size={16} className="text-gray-500" /> },
    { field: "prenom", label: "Prénom", type: "text", required: true, placeholder: "Entrez le prénom", icon: <User size={16} className="text-gray-500" /> },
    { field: "institution", label: "Institution", type: "select", required: true, icon: <Building size={16} className="text-gray-500" /> },
    { field: "email", label: "Email", type: "email", required: true, placeholder: "exemple@domaine.com", icon: <Mail size={16} className="text-gray-500" /> },
    { field: "telephone", label: "Téléphone", type: "text", required: false, placeholder: "Numéro de téléphone (optionnel)", icon: <Phone size={16} className="text-gray-500" /> }
  ];

  return (
    <GenericModal
      isOpen={true}
      onClose={onClose}
      title={isEditMode ? 'Modifier l\'encadrant' : 'Ajouter un encadrant'}
      icon={User}
      size="md"
      loading={isLoading}
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        
       
        {fields.map(({ field, label, type, required, placeholder, icon }) => (
          <div key={field}>
            <label htmlFor={field} className="block text-sm font-medium text-gray-700 mb-1">
              <span className="flex items-center space-x-2">
                {icon}
                <span className="text-sm">
                  {label} 
                  {required && <span className="text-red-500 ml-1">*</span>}
                </span>
              </span>
            </label>
            
            {type === "select" ? (
              <select
                id={field}
                name={field}
                value={formData[field]}
                onChange={handleChange}
                disabled={isLoading}
                className={getInputClassName(field)}
              >
                <option value="Interne">Interne</option>
                <option value="Externe">Externe</option>
              </select>
            ) : (
              <input
                id={field}
                name={field}
                type={type}
                value={formData[field]}
                onChange={handleChange}
                disabled={isLoading}
                className={getInputClassName(field)}
                placeholder={placeholder}
              />
            )}
            
           
            {errors[field] && (
              <p className="mt-1 text-xs text-red-600 flex items-center space-x-1">
                <AlertCircle size={12} />
                <span>{errors[field]}</span>
              </p>
            )}
          </div>
        ))}

        
        {errors.submit && (
          <div className="p-2 bg-red-50 border border-red-200 rounded-lg flex items-center space-x-2">
            <AlertCircle size={14} className="text-red-500" />
            <span className="text-red-700 text-xs">{errors.submit}</span>
          </div>
        )}

        
        <div className="flex justify-end space-x-2 pt-3 border-t border-gray-100">
          <button
            type="button"
            onClick={onClose}
            disabled={isLoading}
            className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium text-sm disabled:opacity-50"
          >
            Annuler
          </button>
          <button
            type="submit"
            disabled={isLoading}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium text-sm disabled:opacity-50 flex items-center justify-center space-x-2"
          >
            {isLoading ? (
              <>
                <Loader2 size={16} className="animate-spin" />
                <span>Enregistrement...</span>
              </>
            ) : (
              <>
                <CheckCircle size={16} />
                <span>{isEditMode ? 'Sauvegarder' : 'Ajouter'}</span>
              </>
            )}
          </button>
        </div>
      </form>
    </GenericModal>
  );
}