import React from "react";
import GenericTable from "./GenericTable";

export default function StagesTable({ stages, loading, error, onStageDeleted, onStageEdit }) {
  const statusConfig = {
    'En cours': 'bg-blue-100 text-blue-800',
    'Terminé': 'bg-red-100 text-red-800',
    'Validé': 'bg-green-100 text-green-800',
    'default': 'bg-gray-100 text-gray-800'
  };

  const columns = [
    { 
      key: 'theme', 
      label: 'Thème', 
      isTruncate: true 
    },
    { 
      key: 'stagiaire', 
      label: 'Stagiaire',
      render: (value, item) => `${item.stagiaire?.prenom || ''} ${item.stagiaire?.nom || ''}`
    },
    { 
      key: 'encadrant', 
      label: 'Encadrant',
      render: (value, item) => item.encadrant ? `${item.encadrant.prenom} ${item.encadrant.nom}` :<span className="text-gray-400 italic">
              Non assigné
            </span>
    },
    { key: 'type_stage', label: 'Type' },
    { 
      key: 'lieu_affectation', 
      label: 'Lieu', 
      responsiveClass: 'hidden lg:table-cell', 
      isTruncate: true 
    },
    { 
      key: 'date_debut', 
      label: 'Début', 
      isDate: true 
    },
    { 
      key: 'date_fin', 
      label: 'Fin', 
      isDate: true 
    },
    { 
      key: 'statut', 
      label: 'Statut', 
      isStatus: true,
      statusConfig: statusConfig
    }
  ];

  const handleDelete = (stage) => {
    if (("Êtes-vous sûr de vouloir supprimer ce stage ?")) {
      fetch(`http://localhost:8000/stages/api/${stage.id}/`, {
        method: "DELETE",
      })
        .then((response) => {
          if (!response.ok) throw new Error("Erreur lors de la suppression");
          onStageDeleted();
        })
        .catch((error) => {
          console.error("Erreur lors de la suppression:", error);
        });
    }
  };

  return (
    <GenericTable
      data={stages}
      columns={columns}
      loading={loading}
      error={error}
      onEdit={onStageEdit}
      onDelete={handleDelete}
      emptyMessage="Aucun stage trouvé."
    />
  );
}